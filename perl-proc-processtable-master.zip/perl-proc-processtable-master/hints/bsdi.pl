symlink "os/bsdi.c", "OS.c" || die "Could not link os/bsdi.c to os/OS.c\n";
